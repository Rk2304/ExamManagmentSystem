package com.exam.ExamManegmentSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamManegmentSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
